const actionPersonal = (state) => ({
  type: 'ACTION_PERSONAL',
  state });

export default actionPersonal;
