const actionProfessional = (state) => ({
  type: 'ACTION_PROFESSIONAL',
  state });
export default actionProfessional;
