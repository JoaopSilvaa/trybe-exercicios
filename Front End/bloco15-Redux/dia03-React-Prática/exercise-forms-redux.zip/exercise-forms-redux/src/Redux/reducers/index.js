import { combineReducers } from 'redux';
import reducerPersonal from './reducerPersonal';
import reducerProfessional from './reducerProfessional';

const rootReducer = combineReducers({
  reducerPersonal,
  reducerProfessional,
});

export default rootReducer;
