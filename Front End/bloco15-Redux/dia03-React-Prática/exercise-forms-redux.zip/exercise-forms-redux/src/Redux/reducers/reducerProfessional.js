const DATA_PROFESSIONAL = {
  state: '',
};

const reducerProfessional = (state = DATA_PROFESSIONAL, action) => {
  switch (action.type) {
  case 'ACTION_PROFESSIONAL':
    return {
      state: action.state,
    };
  default:
    return state;
  }
};

export default reducerProfessional;
