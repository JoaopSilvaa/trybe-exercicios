const DATA_PERSONAL = {
  state: '',
};

const reducerPersonal = (state = DATA_PERSONAL, action) => {
  switch (action.type) {
  case 'ACTION_PERSONAL':
    return {
      state: action.state,
    };
  default:
    return state;
  }
};

export default reducerPersonal;
