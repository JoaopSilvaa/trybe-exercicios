import PropTypes from 'prop-types';
import React, { Component } from 'react';
import { connect } from 'react-redux';

class FormDataDisplay extends Component {
  render() {
    // Recupere as informações do seu estado criado no Redux
    // const {
    //   nome,
    //   email,
    //   cpf,
    //   endereco,
    //   cidade,
    //   estado,
    //   curriculo,
    //   cargo,
    //   descricao,
    // } = this.props;

    const { myFirstState, mySecondState } = this.props;

    return (
      <div>
        <h2>Dados enviados</h2>
        <div>
          Nome:
          {myFirstState.nome}
        </div>
        <div>
          Email:
          { myFirstState.email }
        </div>
        <div>
          CPF:
          { myFirstState.cpf }
        </div>
        <div>
          Endereço:
          { myFirstState.endereco }
        </div>
        <div>
          Cidade:
          { myFirstState.cidade }
        </div>
        <div>
          Estado:
          { myFirstState.estado }
        </div>
        <div>
          Currículo:
          { mySecondState.curriculo }
        </div>
        <div>
          Cargo:
          { mySecondState.cargo }
        </div>
        <div>
          Descrição do cargo:
          { mySecondState.descricao }
        </div>
      </div>
    );
  }
}

FormDataDisplay.propTypes = {
  myFirstState: PropTypes.shape({
    nome: PropTypes.string,
    age: PropTypes.number,
    email: PropTypes.string,
    cpf: PropTypes.string,
    endereco: PropTypes.string,
    cidade: PropTypes.string,
    estado: PropTypes.string,
  }).isRequired,
  mySecondState: PropTypes.shape({
    curriculo: PropTypes.string,
    cargo: PropTypes.string,
    descricao: PropTypes.string,
  }).isRequired,
  // curriculo: PropTypes.string.isRequired,
  // cargo: PropTypes.string.isRequired,
  // descricao: PropTypes.string.isRequired,
};

const mapStateToProps = (state) => ({
  myFirstState: state.reducerPersonal.state,
  mySecondState: state.reducerProfessional.state,
});

export default connect(mapStateToProps, null)(FormDataDisplay);
